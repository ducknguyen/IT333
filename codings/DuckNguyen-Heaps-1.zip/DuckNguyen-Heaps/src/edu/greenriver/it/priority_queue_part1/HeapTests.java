package edu.greenriver.it.priority_queue_part1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This classes verifies the functionality in the MaryHeap class.
 * 
 * @author Duck Nguyen
 * @version 1.0
 */
public class HeapTests
{
	private MaryHeap tester;
	
	@Before
	//this method will run before all other method
	public void setup()
	{
		tester = new MaryHeap<Integer>();
	}
	
	//private method to insert 20 elements to the heap
	private void addThem()
	{
		tester.insert(50);
		tester.insert(29);
		tester.insert(42);
		tester.insert(97);
		tester.insert(66);
		tester.insert(4);
		tester.insert(67);
		tester.insert(12);
		tester.insert(14);
		tester.insert(2);
		tester.insert(52);
		tester.insert(12);
		tester.insert(49);
		tester.insert(31);
		tester.insert(39);
		tester.insert(7);
		tester.insert(71);
		tester.insert(20);
		tester.insert(5);
		tester.insert(10);
	}
	
	/**
	 * Test constructor for Mary
	 * 
	 */
	@Test
	public void testConstructor()
	{
		//testing default constructor
		MaryHeap<Integer> temp = new MaryHeap<Integer>();
		Assert.assertEquals("Size should be 0", 0, temp.size());
	}
	
	/**
	 * Test insert() for Mary
	 * 
	 */
	@Test
	public void testInsert()
	{	
		//calling insert() on an initially empty tree
		tester.insert(50);
		
		Assert.assertEquals("The size() of the heap should be 1 after adding 50",
				1, tester.size());
		
		//Calling insert() elements to non-empty tree (19 more added)
		tester.insert(29);
		tester.insert(42);
		tester.insert(97);
		tester.insert(66);
		tester.insert(4);
		tester.insert(67);
		tester.insert(12);
		tester.insert(14);
		tester.insert(2);
		tester.insert(52);
		tester.insert(12);
		tester.insert(49);
		tester.insert(31);
		tester.insert(39);
		tester.insert(7);
		tester.insert(71);
		tester.insert(20);
		tester.insert(5);
		tester.insert(10);
		
		//check if size has changed after adding 19 elements
		Assert.assertEquals("The size() of the heap should be 20 after adding 19 elements",
				20, tester.size());
	}
	
	/**
	 * Test delMin() for Mary
	 * 
	 */
	@Test
	public void testDelMin()
	{	
		//Calling delMin() on an empty tree
		tester.delMin();
		Assert.assertEquals("delMin() should return null", null, tester.delMin());
		
		//calling delMin() on a non-empty tree
		addThem();
		Assert.assertEquals("The size() of the heap should be 20 after adding 20 elements",
				20, tester.size());
		
		Assert.assertEquals("delMin() should return 2", 2, tester.delMin());
		
		Assert.assertEquals("The size() of the heap should be 19 after removing root (2)",
				19, tester.size());
		
		//loop to repeatedly calling delMin() on the queue
		while(tester.size() > 0)
		{
			tester.delMin();
		}
		Assert.assertEquals("The size() of the heap should be 0 after loop",
				0, tester.size());
	}
	
	/**
	 * Test contains() for Mary
	 * 
	 */
	@Test
	public void testContains()
	{
		//verify that we can find an element in the heap
		addThem();
		Assert.assertTrue("contains() should return true if 71 is found in Mary",tester.contains(71));
		Assert.assertTrue("contains() should return true if 2 is found in Mary",tester.contains(2));
		
		//verify that we cannot find an element in the heap
		Assert.assertFalse("hasWord() should return false if 123123 is not found in Mary",tester.contains(123123));
	}
	
	/**
	 * Test size() for Mary
	 * 
	 */
	@Test
	public void testSize()
	{
		//verify size() is zero when the heap is empty
		Assert.assertEquals("Size should be 0 when Mary is empty", 0, tester.size());
		
		//verify size() increases as word/definition pairs are added
		addThem();
		Assert.assertEquals("Size should be 20 after 20 elements are added", 20, tester.size());
		
		//verify size() decreases when delMin() is called
		tester.delMin();
		Assert.assertEquals("Size should be 19 after delMin() is called", 19, tester.size());
		
		//verify size() increases when more element is added
		tester.insert(100);
		tester.insert(50);
		Assert.assertEquals("Size should be 21 after 2 more elements are added", 21, tester.size());
		
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when Mary is empty", 0, tester.size());
	}
	
	/**
	 * Test isEmpty() for Mary
	 * 
	 */
	@Test
	public void testIsEmpty()
	{
		//isEmpty() should return true because Mary is currently empty
		Assert.assertTrue("isEmpty() should return true because Mary is currently empty",tester.isEmpty());
		
		//add 20 elements to check
		addThem();
		
		//isEmpty() should return false because Mary is not empty
		Assert.assertFalse("isEmpty() should return false because Mary contains 20 elements now",tester.isEmpty());
	}
	
	/**
	 * Test clear() for Mary
	 * 
	 */
	@Test
	public void testClear()
	{
		//add a single element to the heap
		tester.insert(3212);
		
		//check current size of heap
		Assert.assertEquals("The size() of the heap should be 1 after adding 1 element", 1, tester.size());
				
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when Mary is empty", 0, tester.size());	
				
		//add c200 elements to heap 
		addThem();
		tester.insert(3212);
		//check current size of the heap
		Assert.assertEquals("The size() of the dictionary should be 21 after adding 21 more elements", 21, tester.size());
		
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when Mary is empty", 0, tester.size());		
	}
	
	/**
	 * Adding n random values to the queue and retrieving them in sorted order from the queue
	 * Elements should be retrieved in ascending order (or sorted)
	 * Check by adding all delMin() to to array list and check if array list is sorted
	 */
	@Test
	public void test10K()
	{
		Random rand = new Random();
		while(tester.size() < 10000)
		{
			int n = rand.nextInt(10000) + 0;
			tester.insert(n);
		}
		Assert.assertEquals("Size should be 10000", 10000, tester.size());
		
		ArrayList<Integer> arr = new ArrayList<Integer>();
		while(tester.size() > 0)
		{
			int num = (int) tester.delMin();
			arr.add(num);
			System.out.println(arr);
		}
		System.out.println(isSorted(arr));
		
		//test wont pass for some reasons but base on array output seems sorted
		
		Assert.assertEquals("Should return true if sorted", true, isSorted(arr));
	}

	/**
	 * Private method to check if a list is sorted
	 * 
	 */
	private boolean isSorted(ArrayList<Integer> list)
	{
	    boolean sorted = true;        
	    for (int i = 1; i < list.size(); i++) 
	    {
	        if (((Integer) list.get(i-1)).compareTo((Integer) list.get(i)) > 0)
	        {
	        	sorted = false;
	        }
	    }
	    return sorted;
	}

}//end HeapTests