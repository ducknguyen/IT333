package edu.greenriver.it.priority_queue_part2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 * HuffmanEncoding generate a Huffman encoding tree for the book "War and Peace" 
 * and show the compression of bits from the algorithm
 * 
 * 06/10/17
 * @author Duck Nguyen
 * @version 1.0
 */
public class HuffmanEncoding
{
	//private fields
	private static Scanner reader;
	private static HashMap<Character,String> asciiTable = new HashMap<>();
	private static HashMap<Character, String> huffmanMap = new HashMap<>();
	private static HashMap<Character, Double> frequencyCount = new HashMap<>();
	private static PriorityQueue<HuffmanNode> heap = new PriorityQueue<>();
	private static HuffmanNode root;
	
	public static void main(String[] args)
	{
		//Read the war and peace (short) text------------------
		readAscii("ascii_to_binary.txt");
		
		//output binary value
		System.out.println("Analyzing war and peace (short).txt------------------------\n");
		System.out.println("ASCII Output\n");
		toBinary();
		
		//building the tree and print out root frequencies
		root = buildTree();
		System.out.println("\nRoot " + root);
		
		huffmanMap(root, huffmanMap, "");
		System.out.println("\nHuffman Values\n");
		showMap();
		System.out.println();
		System.out.println("Huffman Output:\n");
		printHuffmanOutput("war_and_peace_(short).txt");
		readAscii("ascii_to_binary.txt");
		
		
		//Read the original war and peace text------------------
		System.out.println("\nAnalyzing war and peace.txt------------------------");
		System.out.println("\nASCII Output");
		convertOriginal(asciiTable, "war_and_peace.txt");
		
		root = buildTree();
		huffmanMap(root, huffmanMap, "");
		
		System.out.println("\nHuffman Output");
		convertOriginal(huffmanMap, "war_and_peace.txt");
	}
		
	/**
	 * Read ASCII file to store its data to asciiTable, while putting keys into frequencyCount
	 * 
	 * @param filename - name of file to read
	 */
	public static void readAscii(String filename)
	{
		try
		{
			//read the file
			reader = new Scanner(new File(filename));
			
			while(reader.hasNextLine())
			{
				String lineContent = reader.nextLine();
				
				//split character and its binary value 
				String[] content = lineContent.split(",");
				char character = content[0].charAt(0);
				asciiTable.put(character, content[1].trim());
				frequencyCount.put(character, 0.0);
			}
		} catch(FileNotFoundException e) {
			System.out.println("File Not found" + e.getMessage());
		}
	}
	
	/**
	 * Converts war and peace (short) content to binary values, display binary content and its length;
	 * Count the frequency of the each character and display the result;
	 * Add the character and frequency pairs to the heap as HuffmanNode
	 * 
	 */
	public static void toBinary()
	{
		try
		{
			reader = new Scanner(new File("war_and_peace_(short).txt"));
			int totalLength = 0;
			int charCount = 0;
			
			while(reader.hasNextLine())
			{
				String data = reader.nextLine();
				for(int i = 0; i < data.length(); i++)
				{
					char key = Character.toLowerCase(data.charAt(i));
					String value = asciiTable.get(key);
					
					//update key's value in frequencyCount when key is found
					frequencyCount.replace(key, frequencyCount.get(key) + 1);
					charCount++;
					
					//increment total length 
					totalLength += value.length();
					
					System.out.print(value);
				}
				//line break for output readability
				System.out.println();
			}
			//Show the total length
			System.out.println("\nTotal Length: " + totalLength + "\n");
			
			//Building the heap------------------
			for(Character key : asciiTable.keySet())
			{
				//remove zero values from frequencyCount
				if(frequencyCount.get(key) <= 0)
				{
					frequencyCount.remove(key,frequencyCount.get(key));
				}
				else
				{
					frequencyCount.replace(key, frequencyCount.get(key) / charCount);
					//creating new object and throwing it into heap
					heap.add(new HuffmanNode(key, frequencyCount.get(key), null, null));
				}				
			}
			//show the frequencies
			System.out.println("Frequencies\n");
			for(Character key : frequencyCount.keySet())
			{
				System.out.println(key + ": " + frequencyCount.get(key));
			}
		} catch(FileNotFoundException e) {
			System.out.println("File Not found" + e.getMessage());
		}
	}
	
	/**
	 * Read through the file and display the Huffman Output of the file's content
	 * 
	 * @param filename - name of file to read
	 */
	public static void printHuffmanOutput(String filename)
	{
		try
		{
			//read the file
			reader = new Scanner(new File(filename));
			int totalLength = 0;
			
			while(reader.hasNextLine())
			{
				String data = reader.nextLine();
				//loop through the line
				for(int i = 0; i < data.length(); i++)
				{
					char key = Character.toLowerCase(data.charAt(i));
					String value = huffmanMap.get(key);
					
					//increment total length
					totalLength += value.length();
					
					System.out.print(value);
				}
				//line breaks for readability
				System.out.println();
			}
			//show total length
			System.out.println("\nTotal length: " + totalLength);
			
		} catch(FileNotFoundException e) {
			System.out.println("File Not found" + e.getMessage());
		}
	}
	
	/**
	 * Read through the original war and peace text 
	 * 
	 * @param filename - name of file to read
	 */
	public static void convertOriginal(HashMap<Character, String> map, String filename)
	{
		try
		{
			reader = new Scanner(new File(filename));
			int size = 0;
			int charCount = 0;
			
			while(reader.hasNextLine())
			{
				String data = reader.nextLine();
				for(int i = 0; i < data.length(); i++)
				{
					char key = Character.toLowerCase(data.charAt(i));
					String value = map.get(key);
					
					if(map.equals(asciiTable))
					{
						//increasing key value by 1 every time you get key
						frequencyCount.replace(key, frequencyCount.get(key) + 1);
					}
					charCount++;
					//increasing file size by number of bits by character
					size += value.length();
				}
			}
		
			System.out.println("Total Length: " + size);
			
			//Building the heap-------------
			for(Character key : asciiTable.keySet())
			{
				//remove zero values from frequencyCount
				if(frequencyCount.get(key) <= 0)
				{
					frequencyCount.remove(key,frequencyCount.get(key));
				}
				else
				{
					frequencyCount.replace(key, frequencyCount.get(key) / charCount);
					//adding nodes to heap
					heap.add(new HuffmanNode(key,frequencyCount.get(key), null, null));
				}	
			}
		} catch(FileNotFoundException e) {
			System.out.println("File Not found" + e.getMessage());
		}
	}
	
	/**
	 * Build the Huffman Tree
	 * 
	 */
	public static HuffmanNode buildTree()
	{
		while(heap.size() > 1)
		{
			//repeatedly remove the two lowest nodes
			HuffmanNode left = heap.peek();
			heap.remove(left);
			HuffmanNode right = heap.peek();
			heap.remove(right);
			
			//add them to tree with a new parent whose key is "null" and value is the combine probability of children
			HuffmanNode parent = new HuffmanNode('\u0000', left.probability + right.probability, left, right);
			heap.add(parent);						
		}
		//return parent node at 100% probability
		HuffmanNode root = heap.peek();
		heap.remove(root);
		return root;					
	}
	
	/**
	 * Perform the compression by traversing through the tree
	 * left - 1 ; right - 0
	 * 
	 * @param currentNode - the Node currently at
	 * @param map - map storing the new binary value for each character
	 * @param level - current level in the tree
	 */
	public static Map<Character, String> huffmanMap(HuffmanNode currentNode, HashMap<Character, String> map, String level)
	{
		if(currentNode != null)
		{
			if(currentNode.data != '\u0000')
			{
				//current level on tree
				map.put(currentNode.data, level);
			}
			huffmanMap(currentNode.left, map, level + "1");
			huffmanMap(currentNode.right, map, level + "0");			
		}
		return map;
	}
	
	public static void showMap()
	{
		for(Character key: huffmanMap.keySet())
		{
			System.out.println(key + ": " + huffmanMap.get(key));
		}
	}
	
	/**
	 * HuffmanNode class represents a single HuffmanNode
	 * 
	 */
	public static class HuffmanNode implements Comparable<HuffmanNode>
	{
		//private fields
		private Character data;
	    private Double probability;
	    private HuffmanNode left;
	    private HuffmanNode right;
	    
	    /**
		 * Default constructor for HuffmanNode
		 * 
		 */
		public HuffmanNode(Character data, Double probability, HuffmanNode left, HuffmanNode right) 
		{
			this.data = data;
			this.probability = probability;
			this.left = left;
			this.right = right;
		}
		
		/**
		 * Simple toString method
		 * 
		 */
		public String toString()
		{
			return /*"data: " + data +*/ "frequency: " + probability;
		}
		
		/**
		 * Overriding compareTo to compare based on probability
		 * 
		 */
		@Override
		public int compareTo(HuffmanNode other) 
		{
			return this.probability.compareTo(other.probability);
		}
	}//end HuffmanNode	
}//end HuffmanEncoding