package edu.greenriver.it.part1;

/**
 * An implementation of a Binary Search Tree
 * @author Duck Nguyen
 * @version 1.0
 * 05/08/17
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * A Binary Search Tree data structure 
 * that store elements of generic type T
 *
 * @version 1.0
 */
public class BinarySearchTree<T extends Comparable<T>> {
	
	//private fields
	private Node root;
	private int size;
	
	/**
	 * Node class represent a single node in tree
	 *
	 * @version 1.0
	 */
	private class Node
	{
		// private fields
		private T data;
		private Node left;
		private Node right;
		
		/**
		 * Node constructor
		 *
		 * @param data - value associated with this Node
		 */
		public Node (T data)
		{
			this.data = data;
			//left = right = null; 
		}
		
		/**
		 * Simple toString method for debugging
		 * 
		 * @return String representing a Node, and its left and right child
		 */
		public String toString()
		{
			// using the ternary operator
			String dataString = (data == null) ? "null" : data.toString();
			String leftChild = (left == null) ? "null" : left.data.toString();
			String rightChild = (left == null) ? "null" : right.data.toString();
			
			return leftChild + " <-- " + dataString + " --> " + rightChild;
		}
	}// end Node 

	/**
	 * Binary Search Tree constructor
	 * does nothing.
	 *
	 */
	public BinarySearchTree()
	{
		//do nothing
	}
	
	/**
	 * Adds or update (if duplicate) an element in the tree
	 * @param element - element to be added or updated
	 * @return true if added and false otherwise
	 */
	public boolean addUpdate(T element)
	{
		// add if root is null
		if(root == null)
		{
			root = new Node(element);
			size++;
			return true;
		}
		else
		{
			Node parentNode = null;
			Node currentNode = root;
			
			// traverse tree
			while (currentNode != null)
			{
				parentNode = currentNode;
				int compareCurrent = currentNode.data.compareTo(element);
				if (compareCurrent < 0) // traverse right
				{
					currentNode = currentNode.right;
				}
				else if (compareCurrent > 0) // traverse left
				{
					currentNode = currentNode.left;
				}
				else // duplicate - update
				{
					currentNode.data = element;
					return false;
				}
			}
			
			// reach the last node
			int compare = parentNode.data.compareTo(element);
			if (compare < 0) // add to right
			{
				parentNode.right = new Node(element);
				size++;
				return true;
			}
			else if (compare > 0)  // add to left
			{
				parentNode.left = new Node(element);;
				size++;
				return true;
			}
			// update element
			parentNode.data = element;
			return false;
		}
	}
	
	/**
	 * Check if the tree contains this element
	 * 
	 * @param element - element to check
	 * @return true if exists, false otherwise
	 */
	public boolean contains(T element)
	{
		return get(element) != null;
	}
	
	/**
	 * Get an element a from tree that is equal to this element b
	 *
	 * @param element - element to look for
	 * @return a if exists element a in table equals to element b, 
	 * null otherwise
	 */
	public T get(T element)
	{
		Node temp = root;
		while (temp != null)
		{
			int compare = element.compareTo(temp.data);
			if (compare < 0) // traverse left
			{
				temp = temp.left;
			}
			else if (compare > 0) // traverse right
			{
				temp = temp.right;
			}
			else // found it
			{
				return temp.data;
			}
		}
		// found nothing
		return null;
	}
	
	/**
	 * Check for number of elements in the tree
	 * 
	 * @return number of elements in the tree
	 */
	public int size()
	{
		return size;
	}
	
	/**
	 * Check if there're no elements in the tree
	 * 
	 * @return true tree is empty, false otherwise
	 */
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	/**
	 * Removes all element from the tree
	 */
	public void clear()
	{
		root = null;
		size = 0;
	}
	
	/**
	 * Traverse tree using in order traversal,
	 * and return a sorted list of all elements in tree
	 * 
	 * @return a sorted list of all elements in tree
	 */
	public List<T> inOrder()
	{	
		Stack<Node> stack = new Stack<Node>();
		List<T> sortedData = new ArrayList<>();
		
		if (root == null)
		{
			System.out.println("The tree is empty");
			return sortedData;
		}
		
		Node currentNode = root;
		while (currentNode != null)
		{
			stack.push(currentNode);
			currentNode = currentNode.left;
		}
		
		while (!stack.isEmpty())
		{
			currentNode = stack.pop();
			sortedData.add(currentNode.data);
			
			if (currentNode.right != null)
			{
				currentNode = currentNode.right;
				
				while (currentNode != null)
				{
					stack.push(currentNode);
					currentNode = currentNode.left;
				}
			}
		}
		return sortedData;
	}
}//end BinarySearchTree