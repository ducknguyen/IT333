package representations;

/**
 * Duck Nguyen
 * Implementing a graph class 
 */

import representations.DirectedGraphAL.Edge;

public class TestGraph 
{
	public static void main(String[] args) 
	{		
		//let's store a graph of social network relationships
		DirectedGraphAL<String> socialNetwork = new DirectedGraphAL<>();
		
		//add a few people
		socialNetwork.addVertex("Jose");
		socialNetwork.addVertex("Lisa");
		socialNetwork.addVertex("Bob");
		socialNetwork.addVertex("Kevin");
		socialNetwork.addVertex("Susie");
		
		//add a few relationships
		socialNetwork.addEdge("Jose", "Lisa");
		socialNetwork.addEdge("Lisa", "Jose");
		socialNetwork.addEdge("Bob", "Lisa");
		socialNetwork.addEdge("Kevin", "Lisa");
		socialNetwork.addEdge("Lisa", "Susie");
		socialNetwork.addEdge("Susie", "Jose");
		
		//verify that the graph contains our data
		System.out.println("Vertices in the graph: ");
		for (String vertex : socialNetwork.vertices())
		{			
			System.out.println("V: " + vertex);
		}
		System.out.println();
		
		System.out.println("Edges in the graph: ");
		for (Edge<String> edge : socialNetwork.edges())
		{			
			System.out.println("E: " + edge.getSource() + "--> " + edge.getDest());
		}
		System.out.println();
	}
}