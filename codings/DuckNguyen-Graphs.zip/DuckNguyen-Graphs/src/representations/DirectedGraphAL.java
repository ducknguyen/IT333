package representations;

/**
 * Duck Nguyen
 * Implementing a graph class 
 */

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

/*
 * This is a directed, unweighted graph that uses adjacency lists.
 */
public class DirectedGraphAL<V> 
{
	//use adjacency lists
	public Map<V, LinkedList<Edge<V>>> adjacencyLists;
	
	public DirectedGraphAL(){
		
		adjacencyLists = new HashMap<V, LinkedList<Edge<V>>>();
	}
	
	public boolean addVertex(V element)
	{		
		if(!hasVertex(element))
		{			
			//add it if not already present
			adjacencyLists.put(element, new LinkedList<Edge<V>>());
			return true;			
		}
		else 
		{			
			return false;
		}
	}
	
	public boolean addEdge(V source, V dest)
	{		
		//double check that the vertices are present
		if(!hasVertex(source) || !hasVertex(dest))
		{			
			throw new IllegalArgumentException("One of the following vertices "
					+ "does not exist: " + source + ", " + dest);
		}
		
		//double check that the edge does not exist
		@SuppressWarnings({ "unchecked", "rawtypes" })
		Edge<V> newEdge = new Edge(source,dest);
		LinkedList<Edge<V>> adjacencyList = adjacencyLists.get(source);
		if(adjacencyList.contains(newEdge))
		{			
			return false;
		}
		else
		{			
			adjacencyList.add(newEdge);
			return true;
		}			
	}
	
	public Set<V> vertices()
	{		
		return adjacencyLists.keySet();
	}
	
	public Set<Edge<V >> edges()
	{		
		Set<Edge<V>> results = new HashSet<Edge<V>>();
		
		//loop over each adjacency list
		for(LinkedList<Edge<V>> adjacencyList : adjacencyLists.values())
		{			
			results.addAll(adjacencyList);
		}		
		return results;		
	}
	
	public boolean hasVertex(V element)
	{		
		return adjacencyLists.containsKey(element);
	}
	
	public static class Edge<V>
	{		
		private V source;
		private V dest;
		
		public Edge(V source, V dest)
		{			
			this.source = source;
			this.dest = dest;
		}

		public V getSource() 
		{
			return source;
		}

		public V getDest() 
		{
			return dest;
		}

		@Override
		public int hashCode() 
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + ((dest == null) ? 0 : dest.hashCode());
			result = prime * result + ((source == null) ? 0 : source.hashCode());
			return result;
		}

		@SuppressWarnings("unchecked")
		@Override
		public boolean equals(Object other)
		{			
			//some quick checks here...
			if (this == other)
			{
				return true;
			}
			else if (other == null)
			{
				return false;
			}
			else if (getClass() != other.getClass())
			{
				return false;
			}	
			Edge<V> otherEdge = (Edge<V>) other;
			return this.source.equals(otherEdge.source) &&
					this.dest.equals(otherEdge.dest);
		}		
	}
}