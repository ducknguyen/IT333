package part2;

import java.util.Arrays;

/**
 * Duck Nguyen
 * 04/21/17
 * UniqueList.java
 * UniqueList an implementation of Java ArrayList Class
 */

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.omg.CORBA.DynArray;

public class UniqueList <T> implements List<T>
{
	private T arr[];
	private static final int INITIAL_CAPACITY = 10;
	private int size = 0;
	private int modCount = 0;
	
	/**
	 * Default Constructor initialize an ArrayList with capacity 10
	 */
	public UniqueList()
	{
		arr = (T[]) new Object[INITIAL_CAPACITY];
	}
	
	/**
	 * Constructor
	 * 
	 * @param capacity initialize an ArrayList with this capacity
	 * @throws IllegalArgumentException if capacity is negative
	 */
	public UniqueList(int capacity)
	{
		if (capacity < 0)
		{
			throw new IllegalArgumentException();
		}
		arr = (T[]) new Object[capacity];		
	}
	
	// private resize method to dynamically resizing the ArrayList
	private void resize()
	{
		arr = Arrays.copyOf(arr, arr.length * 2);
	}
	
	// private checkBound to check if index is out or range inclusively
	private void inclusiveCheck (int index)
	{
		if(index > size)
			throw new IndexOutOfBoundsException();
	}
	
	// private checkBound to check if index is out or range exclusively
	private void exclusiveCheck(int index)
	{
		if(index >= size)
			throw new IndexOutOfBoundsException();
	}
		
	/**
	 * Appends the element to the end of the list.
	 * No duplicates allowed
	 * 
	 * @param element to be append to list
	 * @return true if not a duplicate
	 */
	@Override
	public boolean add(T element)
	{
		if(arr.length - size <= 5) 
			resize();
		
		if(Arrays.asList(arr).contains(element))
			return false;
		
		arr[size++] = element;
		return true;
	}
	
	/**
	 * Removes all element in the list
	 */
	@Override
	public void clear()
	{
		if(size > 0)
		{
			Arrays.fill(arr, 0, size, null);
			size = 0;
		}
	}
	
	/**
	 * Returns true if element is found in the ArrayList
	 * 
	 * @param element to be tested if in ArrayList
	 * @return true if ArrayList contains the element
	 */
	@Override
	public boolean contains(Object element)
	{
		/* code clean up
		for (Object e : arr)
		{
			if (e == element && element.equals(e))
				return true;
		}
		return false;
		*/
		return indexOf(element) != -1;
	}
	
	/**
	 * Check if ArrayList is empty
	 * 
	 * @return true if no elements are found (or size == 0)
	 */
	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	/**
	 * Remove the first occurrence of the element in ArrayList
	 * 
	 * @param element to be removed from ArrayList
	 * @return true if internal array changes as a result removal
	 */
	@Override
	public boolean remove(Object element)
	{
		for(int i = 0; i < size; i++)
		{
			if(arr[i].equals(element))
			{
				for(int j = i; j < size-1; j++)
				{
					arr[j] = arr[j+1];
				}
				
				arr[size-1] = null;
				size--;
				
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns number of elements in the ArrayList
	 * 
	 * @return the ArrayList's size
	 */
	@Override
	public int size()
	{
		return size;
	}
	
	/**
	 * Return an array containing all element(s) from the ArrayList
	 * 
	 * @return an array version of the ArrayList
	 */
	@Override
	public Object[] toArray()
	{
		T[] copy = (T[]) new Object[size];
		System.arraycopy(arr, 0, copy, 0, size);
		return copy;
	}
	
	/**
	 * Return an iterator over the elements in this list
	 * 
	 * @return an iterator over the elements in this list in proper sequence
	 */
	@Override
	public Iterator<T> iterator()
	{
		return new ArrayListIterator(arr, this);
	}
	
	private class ArrayListIterator implements Iterator<T>
	{
		private T[] data;
		private UniqueList<T> parent;
		private int current = 0;
		private int modCount; 
		
		/**
		 * Constructor for the Iterator 
		 * 
		 * @param data - the array 
		 * @param parent - the ArrayList 
		 * @return an iterator over the elements in this list in proper sequence
		 */
		public ArrayListIterator(T[] data, UniqueList<T> parent)
		{
			this.data = data;
			this.parent = parent;
			this.modCount = parent.modCount;
		}
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return current < data.length && data[current] != null;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			T next = data[current];
			current++;
			return next;
		}
		
	}
	
	// ****** INDEX-BASED METHODS ******

	/**
	 * Inserts the specified element at the specified position in this list
	 * 
	 * @param index at which the specified element is to be inserted
	 * @param element to be inserted
	 * @return the element at the given index
	 */
	@Override
	public void add(int index, T element)
	{
		inclusiveCheck(index);
		if (size == arr.length)
			resize();
		if (index != size)
		{
			System.arraycopy(arr, index, arr, index + 1, size - index);
			arr[index] = element;
			size++;
		}
	}

	/**
	 * Retrieves element at the provided index
	 * 
	 * @param index of the element in array (if exists)
	 * @return the element at the given index
	 */
	@Override
	public T get(int index)
	{
		exclusiveCheck(index);
		return (T) arr[index];
	}
    
	/**
	 * Replaces the element at the specified position in this list with the specified element
	 * 
	 * @param index of the element to replace
	 * @param element to be stored at the specified position 
	 * @return 
	 */
	@Override
	public T set(int index, T element)
	{
		exclusiveCheck(index);
		T temp = (T) arr[index];
		arr[index] = element;
		return temp;
	} 
	
	/**
	 * Returns the index of the first occurrence of the specified element in this list, or -1 
	 * if this list does not contain the element 
	 * 
	 * @param element to search for 
	 * @return the index of the first occurrence of the specified element in this list, or -1 
	 * if this list does not contain the element
	 */
	@Override
	public int indexOf(Object element)
	{
		for(int i = 0; i < size; i++)
		{
			if (element.equals(arr[i]))
				return i;
		}
		return -1;
	}

	/**
	 * Removes the element at the specified position in this list. Returns the element
	 * that was removed from the list
	 * 
	 * @param the index of the element to be removed 
	 * @return the element previously at the specified position
	 */
	@Override
	public T remove(int index)
	{
		exclusiveCheck(index);
		T removed = (T) arr[index];
		if(index != --size)
		{
			System.arraycopy(arr, index + 1, arr, index, size-index);
		}
		return removed;
	}

	/**
	 * Returns the index of the last occurrence of the specified element in this list
	 * 
	 * @param element to search for
	 * @return the index of the last occurrence of the specified element in this list
	 */
	@Override
	public int lastIndexOf(Object element)
	{
		for(int i = size - 1; i >= 0; i--)
		{
			if(element.equals(arr[i]))
				return i;
		}
		return -1;
	}
	
	// ****** SET METHODS ******
	/**
	 * Inserts all of the element in the specified collection into this list at the specified 
	 * position.
	 * 
	 * @param index at which to insert the first element from the specified collection
	 * @param collection containing elements to be added to this list 
	 * @return true if this list changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends T> other)
	{
		boolean changed = false;
		for(Object obj:other)
		{
			if(add((T) obj))
			{
				changed = true;
			}
		}
		return changed;
	}

	/**
	 * Insert all of the elements in the specified collection into this list at the 
	 * specified position
	 * 
	 * @param index at which to insert the first element from the specified collection
	 * @param other collection containing elements to be added to this list
	 * @return the element at the given index
	 */
	@Override
	public boolean addAll(int index, Collection<? extends T> other)
	{
		inclusiveCheck(index);
		if(size == arr.length)
		{
			resize();
		}
		boolean changed = false;
		int indexCounter = 0;
		for(Object obj:other)
		{
			if(!contains(obj))
			{
				add((index+indexCounter), (T)obj);
				indexCounter++;
				changed = true;
			}
		}
		
		return changed;		
	}

	/**
	 * Return true if this list contains all of the elements of the specified collection
	 * 
	 * @param other collection to be checked for containment in this list 
	 * @return true if this list contains all of the elements of specified collection
	 */
	@Override
	public boolean containsAll(Collection<?> other)
	{
		for(Object element : other)
		{
			if(!contains(element))
				return false;
		}
		return true;
	}

	/**
	 * Removes from this list all of its elements that are contained in 
	 * the specified collection
	 * 
	 * @param other collection containing elements to be removed from this list
	 * @return true if this list changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> other)
	{
		for(Object element : other)
		{
			remove(element);
		}
		return true;
	}

	/**
	 * Retains only the elements in this list that are contained in the 
	 * specified collection
	 * 
	 * @param collection containing elements to be retained in this list
	 * @return true if this list changed as a result of the call
	 */
	@Override
	public boolean retainAll(Collection<?> other)
	{
		UniqueList<T> temp = new UniqueList<T>();
		
		for(Object obj:other)
		{
			for(T element : this)
			{
				if(!other.contains(element))
				{
					temp.add(element);
				}
			}
		}
		
		if(removeAll(temp))
		{
			return true;
		}
		return false;
	}

	
	
	// ****** DO NOT IMPLEMENT ******

	@Override
	public List<T> subList(int start, int end)
	{
		throw new UnsupportedOperationException("subList() is not supported");
	}

	@SuppressWarnings("hiding")
	@Override
	public <T> T[] toArray(T[] arrayToFill)
	{
		throw new UnsupportedOperationException("toArray() is not supported");
	}

	@Override
	public ListIterator<T> listIterator()
	{
		throw new UnsupportedOperationException("listIterator() is not supported");
	}

	@Override
	public ListIterator<T> listIterator(int index)
	{
		throw new UnsupportedOperationException("listIterator() is not supported");
	}
}
