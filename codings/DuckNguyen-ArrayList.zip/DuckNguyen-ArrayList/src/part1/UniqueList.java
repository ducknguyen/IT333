package part1;

import java.util.Arrays;

/**
 * Duck Nguyen
 * 04/13/17
 * UniqueList.java
 * UniqueList is part 1 of an ongoing implementation of ArrayList Class
 */

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.omg.CORBA.DynArray;

public class UniqueList <T> implements List<T>
{
	private Object arr[];
	private static final int INITIAL_CAPACITY = 10;
	private int size = 0;
	
	/**
	 * Default Constructor initialize an ArrayList with capacity 10
	 */
	public UniqueList()
	{
		arr = new Object[INITIAL_CAPACITY];
	}
	
	/**
	 * Constructor
	 * 
	 * @param capacity initialize an ArrayList with this capacity
	 * @throws IllegalArgumentException if capacity is negative
	 */
	public UniqueList(int capacity)
	{
		if (capacity < 0)
		{
			throw new IllegalArgumentException();
		}
		arr = new Object[capacity];		
	}
	
	// private resize method to dynamically resizing the ArrayList
	private void resize()
	{
		arr = Arrays.copyOf(arr, arr.length * 2);
	}
	
	/**
	 * Appends the element to the end of the list.
	 * No duplicates allowed
	 * 
	 * @param element to be append to list
	 * @return true if not a duplciate
	 */
	@Override
	public boolean add(T element)
	{
		if(arr.length - size <= 5)
		{
			resize();
		}
		
		if(Arrays.asList(arr).contains(element))
		{
			return false;
		}
		
		arr[size++] = element;
		return true;
	}
	
	/**
	 * Removes all element in the list
	 */
	@Override
	public void clear()
	{
		if(size > 0)
		{
			Arrays.fill(arr, 0, size, null);
			size = 0;
		}
	}
	
	/**
	 * Returns true if element is found in the ArrayList
	 * 
	 * @param element to be tested if in ArrayList
	 * @return true if ArrayList contains the element
	 */
	@Override
	public boolean contains(Object element)
	{
		for (Object e : arr)
		{
			if (e == element && element.equals(e))
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check if ArrayList is empty
	 * 
	 * @return true if no elements are found (or size == 0)
	 */
	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	/**
	 * Remove the first occurence of the element in ArrayList
	 * 
	 * @param element to be removed from ArrayList
	 * @return true if internal array changes as a result removal
	 */
	@Override
	public boolean remove(Object element)
	{
		for(int i = 0; i < size; i++)
		{
			if(arr[i].equals(element))
			{
				for(int j = i; j < size-1; j++)
				{
					arr[j] = arr[j+1];
				}
				
				arr[size-1] = null;
				size--;
				
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns number of elements in the ArrayList
	 * 
	 * @return the ArrayList's size
	 */
	@Override
	public int size()
	{
		return size;
	}
	
	/**
	 * Return an array containing all element(s) from the ArrayList
	 * 
	 * @return an array version of the ArrayList
	 */
	@Override
	public Object[] toArray()
	{
		T[] copy = (T[]) new Object[size];
		System.arraycopy(arr, 0, copy, 0, size);
		return copy;
	}

	@Override
	public Iterator<T> iterator()
	{
		return null;  
	}
	
	// ****** INDEX-BASED METHODS ******

	@Override
	public void add(int index, T element)
	{
		
	}

	/**
	 * Retrives element at the provided index
	 * 
	 * @param index of the element in array (if exists)
	 * @return the element at the given index
	 */
	@Override
	public T get(int index)
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException(); 
		}
		return (T) arr[index];
	}
           
	@Override
	public T set(int index, T element)
	{
		return null;
	}

	@Override
	public int indexOf(Object element)
	{
		return 0;
	}

	@Override
	public T remove(int index)
	{
		return null;
	}

	@Override
	public int lastIndexOf(Object element)
	{
		return 0;
	}
	
	// ****** SET METHODS ******

	@Override
	public boolean addAll(Collection<? extends T> other)
	{
		return false;
	}

	@Override
	public boolean addAll(int index, Collection<? extends T> other)
	{
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> other)
	{
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> other)
	{
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> other)
	{
		return false;
	}
	
	// ****** DO NOT IMPLEMENT ******

	@Override
	public List<T> subList(int start, int end)
	{
		throw new UnsupportedOperationException("subList() is not supported");
	}

	@SuppressWarnings("hiding")
	@Override
	public <T> T[] toArray(T[] arrayToFill)
	{
		throw new UnsupportedOperationException("toArray() is not supported");
	}

	@Override
	public ListIterator<T> listIterator()
	{
		throw new UnsupportedOperationException("listIterator() is not supported");
	}

	@Override
	public ListIterator<T> listIterator(int index)
	{
		throw new UnsupportedOperationException("listIterator() is not supported");
	}
}
