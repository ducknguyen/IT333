package edu.greenriver.it.data_structures;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * BagTests.Java
 * BagTests is a J Unit testing for BagSet class
 * 
 * @author Duck Nguyen
 * @version 1.0
 * 4/25/17
 */

public class BagTests 
{
	private BagSet<Integer> set;

	@Before
	public void setup() 
	{
		set = new BagSet<>(5);
	}

	@Test
	public void testConstructor() 
	{
		//test that an IllegalArgumentException is thrown when a non-positive capacity is given
		try
		{
			set = new BagSet<>(0); //bad capacity
			Assert.fail("An illegal argument exception was NOT thrown when entering a non-positive capacity.");
			//we should not be able to reach this line...
		}
		catch(IllegalArgumentException e){
			//the goal is to reach this catch block, everything is fine!
			
		}
	}

	@Test
	public void testAdd() 
	{
		// make sure we can add a few items to the bagset
		set.add(10);
		set.add(20);
		set.add(30);

		Assert.assertEquals("the size() of the BagSet should be 3 after adding 3 elements.", 3, set.size());

		// verify we cannot add duplicates
		set.add(10);
		Assert.assertEquals("The size() of the BagSet should remain 3 after adding duplicate elements.", 3, set.size());

		// verify that you cannot add more elements than the capacity
		set.add(40);
		set.add(50);
		set.add(60);// this should not be added to the bagset
		Assert.assertEquals("size() has increased beyond the capacity of the BagSet", 5, set.size());
	}

	@Test
	public void testContains() 
	{
		// verify that we can find an element inside the BagSet
		set.add(10);
		Assert.assertTrue("Contains(); should return true if the element is found in the bagset", set.contains(10));

		Assert.assertFalse("Contains(); should return false if the element is NOT found in the bagset",
				set.contains(20));

	}

	@Test
	public void testSize() 
	{
		// verify size() is zero for an empty bag set
		Assert.assertEquals("Size() should be zero for an empty bagset", 0, set.size());

		// verify size() increases as we add elements
		set.add(10);
		Assert.assertEquals("Size() should increase after calling add()", 1, set.size());
		set.add(20);
		Assert.assertEquals("Size() should increase after calling add()", 2, set.size());
		// verify size() decreases as we remove elements
		set.remove(10);
		Assert.assertEquals("Size() should decrease after calling remove()", 1, set.size());
		set.remove(20);
		Assert.assertEquals("Size() should decrease after calling remove()", 0, set.size());
	}

	@Test
	public void testRemove() 
	{
		set.add(10);
		set.add(20);
		set.add(30);

		set.remove(10);
		Assert.assertEquals("Size() should be 2 after removing an element", 2, set.size());

		// existent element
		boolean result = set.remove(20);
		Assert.assertTrue("removing an element that exists in the bag should return true", result);

		// non-existent element
		result = set.remove(-10);
		Assert.assertFalse("removing an element that does not exist in the bag should return false", result);

		// can we repeatedly remove the same element
		result = set.remove(20);
		Assert.assertFalse("removing a previously removed element should return false", result);

	}
}//end BagTests