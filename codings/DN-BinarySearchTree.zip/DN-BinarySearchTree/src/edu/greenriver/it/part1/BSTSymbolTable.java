package edu.greenriver.it.part1;

/**
 * An implementation of a Symbol Table
 * @author Duck Nguyen
 * @version 1.0
 * 05/08/17
 */

import java.util.ArrayList;
import java.util.List;

/**
 * A BST symbol table that store key/value pairs
 * sorted by key
 * @version 1.0
 */
public class BSTSymbolTable<K extends Comparable<K>, V> 
{
	// internal tree structure
	private BinarySearchTree<Entry> data;

	/**
	 * Entry class represent a single pair of key/value
	 *
	 * @version 1.0
	 */
	private class Entry implements Comparable<Entry>
	{
		private K key;
		private V value;
		
		/**
		 * Entry constructor
		 *
		 * @param <K> key   - key associated with this entry
		 * @param <V> value - value associated with key
		 */
		public Entry (K key, V value)
		{
			this.key = key;
			this.value = value; 
		}
		
		/**
		 * comapreTo override to compare base on key
		 * 
		 * @return 0 if equal, -1 if less than, and 1 if greater than
		 */
		@Override
		public int compareTo(Entry other) 
		{	
			return this.key.compareTo(other.key);
		}
		
		/**
		 * Simple toString method for debugging
		 * 
		 * @return String representing a Entry's key and value
		 */
		public String toString()
		{
			return "Key is: " + key + "; value is: " + value;
		}
	}//end Entry class
	
	
	/**
	 * BSTSymbolTable constructor
	 * does nothing.
	 *
	 */
	public BSTSymbolTable()
	{
		data = new BinarySearchTree<Entry>();
	}
	
	/**
	 * Adds a key/value pair to the map if none present
	 * if present replace that pair with this
	 * 
	 * @param <K> key   - key associated with this entry
	 * @param <V> value - value associated with key
	 * @return true if added and false otherwise
	 */
	public boolean put(K key, V value)
	{
		if (key == null) throw new IllegalArgumentException();
		return data.addUpdate(new Entry(key, value));
	}
	
	/**
	 * Get a key A from table that is equal to this key B
	 *
	 * @param key - key to look for
	 * @return A if exists key A in table equals to key B, 
	 * null otherwise
	 */
	public V get (K key)
	{
		if (key == null) throw new IllegalArgumentException();
		Entry currentEntry = new Entry(key, null);
		Entry tempEntry = data.get(currentEntry);
		if (tempEntry == null)
		{
			return null;
		}
		return tempEntry.value;
	}
	
	/**
	 * Check if the table contains this key
	 * 
	 * @param key - key to look for
	 * @return true if exists, false otherwise
	 */
	public boolean containsKey(K key)
	{
		Entry currentEntry = new Entry(key, null);
		return data.contains(currentEntry);
		
	}
	
	/**
	 * Check if the table contains this value
	 * 
	 * @param value - value to look for
	 * @return true if exists, false otherwise
	 */
	public boolean containsValue (V value)
	{
		// grab a list of values
		List<V> dataValues = values();
		
		for(int i = 0; i < dataValues.size(); i++)
		{
			//System.out.println("in the loop here");
			if (dataValues.get(i).equals(value))
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Traverse table using in order traversal,
	 * and return a sorted list of all keys in table
	 * 
	 * @return a sorted list of all keys in table
	 */
	public List<K> keys()
	{
		List<Entry> entries = data.inOrder();
		List<K> keyList = new ArrayList<K>();
		
		for(Entry entry : entries)
		{
			keyList.add(entry.key);
		}
		
		return keyList;
	}
	
	/**
	 * Traverse table using in order traversal,
	 * and return an unsorted list of all values in table
	 * 
	 * @return an unsorted list of all values in table
	 */
	public List<V> values()
	{
		List<Entry> entries = data.inOrder();
		List<V> values = new ArrayList<V>();
		
		for (Entry entry : entries)
		{
			values.add(entry.value);
		}
		return values;
	}
	
	/**
	 * Check for number of entries in the table
	 * 
	 * @return number of entries in the table
	 */
	public int size()
	{
		return data.size();
	}
	
	/**
	 * Check if there're no entries in the table
	 * 
	 * @return true if table is empty, false otherwise
	 */
	public boolean isEmpty()
	{
		return data.isEmpty();
	}
	
	/**
	 * Removes all entries from the table
	 */
	public void clear()
	{
		data.clear();
	}
}// end BSTSymbolTable