package edu.greenriver.it.part1;

/**
 * Informal test class for the BSTSymbolTable class
 * @author Duck Nguyen
 * @version 1.0
 * 05/08/17
 */
public class InformalTableTest {

	public static void main(String[] args) {
		
		BSTSymbolTable<String, Integer> symbolTable = new BSTSymbolTable<>();
		
		// put() method and size() method 
		lazyPrint("adding several key/value pairs to the table \n* retrieve values using get");
		
		symbolTable.put("Duck" ,1);
		symbolTable.put("cobra",2);
		symbolTable.put("timon",3);
		symbolTable.put("pumba",4);
		symbolTable.put("Simba",5);
		System.out.println("Current size after added 5 elements: " + symbolTable.size());
		
		// get() method
		System.out.println("Duck position? " + symbolTable.get("Duck"));
		System.out.println("Hodor position? " + symbolTable.get("hodor"));
		symbolTable.put("Duck",10);
		System.out.println("Duck position after update? " + symbolTable.get("Duck"));
		System.out.println();
		
		// containsKey() and containsValue() method
		lazyPrint("check if table contains keys and values");
		
		System.out.println("Table contains duck? " + symbolTable.containsKey("duck"));
		System.out.println("Table contains Duck? " + symbolTable.containsKey("Duck"));
		System.out.println("Table contains pumba? " + symbolTable.containsKey("pumba"));
		System.out.println("Table contains dinosaur? " + symbolTable.containsKey("dinosaur"));
		
		System.out.println("\nTable contains timon? " + symbolTable.containsKey("timon"));
		System.out.println("Table contains value 4? " + symbolTable.containsValue(4));
		System.out.println("Table contains value 1? " + symbolTable.containsValue(1));
		System.out.println("Table contains value 20? " + symbolTable.containsValue(20));
		System.out.println();
		
		// size(), isEmpty(), and clear() methods
		lazyPrint("verify the number of key/value pairs in the tree are tracked correctly");
		System.out.println("Current size: " + symbolTable.size());
		
		symbolTable.clear();
		
		System.out.println("Clearing table content... ");
		System.out.println("Is table empty? " + symbolTable.isEmpty());
		System.out.println("Current size: " + symbolTable.size());
		
		symbolTable.put("meaning of life?", 42);
		System.out.println("Current size after added 1 element: " + symbolTable.size());
		System.out.println();
		
		// key() and values() methods
		lazyPrint("verify that output from key() are sorted and able to output values()");
		symbolTable.put("Duck",1);
		symbolTable.put("cobra",2);
		symbolTable.put("timon",3);
		symbolTable.put("pumba",4);
		symbolTable.put("Simba",5);
		symbolTable.put("dinosaur",6);
		
		System.out.println("Keys list: " + symbolTable.keys());
		System.out.println("Values list: " + symbolTable.values());
		System.out.println();
	}
	
	// lazyPrint method
	protected static void lazyPrint(String text)
	{
		System.out.println("***************************************************************************");
		System.out.println("* " + text);
		System.out.println("***************************************************************************");
	}
}
