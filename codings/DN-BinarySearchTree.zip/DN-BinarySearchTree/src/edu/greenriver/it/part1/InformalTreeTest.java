package edu.greenriver.it.part1;

/**
 * Informal test class for the Binary Search Tree class
 * @author Duck Nguyen
 * @version 1.0
 * 05/08/17
 */

public class InformalTreeTest 
{
	public static void main(String[] args)
	{
		BinarySearchTree<Integer> bst = new BinarySearchTree<>();
		
		// addUpdate(n) method
		// values are similar to Josh's BST video for easy read
		lazyPrint("adding several elements to the binary search tree");
		bst.addUpdate(60);
		bst.addUpdate(41);
		bst.addUpdate(74);
		bst.addUpdate(16);
		bst.addUpdate(53);	
		bst.addUpdate(46);
		bst.addUpdate(55);	
		bst.addUpdate(42);
		
		System.out.println("Binary tree size: " + bst.size() + " (8 elements added)");
		bst.addUpdate(16); //duplicate
		bst.addUpdate(60); //duplicate
		System.out.println("Adding duplicates 60: " + bst.addUpdate(60) + ", and 16: " + bst.addUpdate(16));
		System.out.println("Binary tree size after trying to add duplicates: " + bst.size());
		
		System.out.println();
		
		// contains(n) method
		lazyPrint("verify that elements are within the tree using contains()");
		System.out.println("contains(60) " + bst.contains(60));
		System.out.println("contains(74) " + bst.contains(74));
		System.out.println("contains(100) " + bst.contains(100));
		System.out.println("contains(0) " + bst.contains(0));
		
		System.out.println();
		
		// size(), isEmpty(), and clear()
		lazyPrint("verify the number of elements in tree are tracked correctly \n* using size() isEmpty(), and clear()");
		System.out.println("Current size: " + bst.size());
		System.out.println("Add 100 to tree: " + bst.addUpdate(100) + "\nCurrent size: " + bst.size());
		System.out.println("\nClearing tree's data....");
		bst.clear();
		System.out.println("Check if tree is empty: " + bst.isEmpty() + "\nCurrent size: " + bst.size());
		
		System.out.println();
		
		// inOrder() method
		lazyPrint("retrieving all elements in the tree using inorder traversal");
		
		bst.addUpdate(60);
		bst.addUpdate(41);
		bst.addUpdate(74);
		bst.addUpdate(16);
		bst.addUpdate(53);	
		bst.addUpdate(46);
		bst.addUpdate(55);	
		bst.addUpdate(42);
		bst.addUpdate(100);
		bst.addUpdate(65);
		
		System.out.println("Inorder traversal (L-Ro-R): " + bst.inOrder());
		System.out.println();
		
		// get(n) method
		lazyPrint("retrieve elements using get()");
		System.out.println("Current root is: " + bst.get(60));
		System.out.println("Got 46? " + bst.get(46));
		System.out.println("Got 74? " + bst.get(74));
		System.out.println("Got 120? " + bst.get(120));
		System.out.println();
	}
	
	// lazyPrint method
	protected static void lazyPrint(String text)
	{
		System.out.println("***************************************************************************");
		System.out.println("* " + text);
		System.out.println("*");
		System.out.println("***************************************************************************");
	}
}

