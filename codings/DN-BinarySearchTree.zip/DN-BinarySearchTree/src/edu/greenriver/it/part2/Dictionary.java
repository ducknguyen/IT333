package edu.greenriver.it.part2;

import java.util.List;

import edu.greenriver.it.part1.BSTSymbolTable;

/**
 * A Dictionary class that uses the symbol table from part 1
 * @author Duck Nguyen
 * @version 1.0
 * 05/16/17
 */
public class Dictionary {
	private BSTSymbolTable<String, String> words;
	
	/**
	 * Default constructor for our dictionary
	 * 
	 */
	public Dictionary()
	{
		words = new BSTSymbolTable<>();
	}

	/**
	 * Parametized constructor for our dictionary
	 * 
	 * @param words - array of words to be added
	 * @param definitions - array of definitions associated with the words
	 * 
	 * @throws IllegalArgumentException if input arrays size differ
	 * @throws IllegalStateException if words array is not sorted lexicographically
	 */
	public Dictionary(String[] words, String[] definitions)
	{
		this.words = new BSTSymbolTable<String, String>();
		
		if(words.length != definitions.length)
		{
			throw new IllegalArgumentException();
		}
		
		if(!isSorted(words))
		{
			throw new IllegalStateException();
		}
		//similar to code from mergeSort video
		balancedAdd(words, definitions, 0, words.length);
	}
	
	//recursively balancing and adding elements
	private void balancedAdd(String[] words, String[] definitions)
	{
		//one or zero element = sorted
		if (words.length <= 1)
		{
			return;
		}
		//else call recursion add
		balancedAdd(words, definitions, 0, words.length);
	}
	
	//helper function
	private void balancedAdd(String[] words, String[] definitions, int lo, int hi)
	{
		//base case when low and high are out of order
		if (lo == hi)
		{
			return;
		}
		
		//select middle element to be added
		//split the array into two halves
		int mid = (lo + hi) / 2;
		this.words.put(words[mid], definitions[mid]);
		
		//recursive perform the above operation 
		//to the lef half, and right half
		balancedAdd(words, definitions, lo, mid);
		balancedAdd(words, definitions, mid + 1, hi);		
	}	
	
	//check if an array is sorted or not
	private boolean isSorted(String[] arr)
	{
	    for (int i = 0; i < arr.length - 1; i++) {
	        if (arr[i].compareTo(arr[i + 1]) > 0) {
	            return false; // array is not sorted.
	        }
	    }
	    return true; 
	}
	
	/**
	 * Adds a word/definition pair if not exist 
	 * Updates a word with new definition is already exist 
	 * 
	 * @param word - word to be added (or update)
	 * @param definition - definition associated with word
	 * @return true if added, false if updated
	 */
	public boolean updateDictionary(String word, String definition)
	{
		return words.put(word, definition);
	}
	
	/**
	 * Check if the our dictionary contains the word
	 * 
	 * @param word - word to look for
	 * @return true if exists, false otherwise
	 */
	public boolean hasWord(String word)
	{
		return words.containsKey(word);
	}
	
	/**
	 * Returns the definition of the input word from the dictionary 
	 * 
	 * @param word - word of which definition is being looked up
	 * @return the word's definition if found, null otherwise
	 */
	public String define(String word)
	{
		return words.get(word);
	}
	
	/**
	 * Returns a list of the words in our dictionary
	 * 
	 * @return an ordered list of the words in the dictionary 
	 */
	public List<String> words()
	{
		return words.keys();
	}
	
	/**
	 * Returns a list of the definitions in our dictionary
	 * 
	 * @return an unordered list of the definitions in the dictionary
	 */
	public List<String> definitions()
	{
		return words.values();
	}
	
	/**
	 * Check for number of word/definition pairs in our dictionary
	 * 
	 * @return number of word/definition pairs in the dictionary
	 */
	public int size()
	{
		return words.size();
	}
	
	/**
	 * Check if our dictionary is empty
	 * 
	 * @return true if empty, false otherwise
	 */
	public boolean isEmpty()
	{
		return words.isEmpty();
	}
	
	/**
	 * Remove all word/definition pairs in our dictionary
	 * 
	 */
	public void clear()
	{
		words.clear();
	}
}// end Dictionary