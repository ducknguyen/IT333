package edu.greenriver.it.part2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Console program prompting user with options
 * to interact with our dictionary
 * @author Duck Nguyen
 * @version 1.0
 * 05/16/17
 */

public class UserConsole 
{ 
	//private fields
	private static Dictionary dictionary;
	private static Scanner scan;
	private static Scanner read;
	private static int choice;
	private static String userWord;
	private static String userDef;
	

	public static void main(String[] args) 
	{
		//some fence post
		System.out.println("-----Welcome to my Dictionary-----");
		options();
		scan = new Scanner(System.in);
		choice = scan.nextInt();
		
		//evaluate and continue to prompt
		while (choice != 3)
		{
			check();
			options();
			choice = scan.nextInt();
		}
	}
	
	/**
	 * Prints a list of options to the console
	 */
	public static void options()
	{
		System.out.println("1. Load dictionary");
		System.out.println("2. Lookup word");
		System.out.println("3. Exit");
	}
	
	/**
	 * Evaluate user choice and return the proper respond
	 */
	public static void check()
	{
		// choice is 1 -> create new dictionary
		if (choice == 1)
		{
			//load dictionary
			try 
			{
				//ArrayLists for easy add operation
				List<String> wordTemp = new ArrayList<>();
				List<String> defTemp = new ArrayList<>();
				read = new Scanner(new File("dictionary.txt"));
				
				//read the file for word/definition pairs
				while (read.hasNextLine())
				{
					String line = read.nextLine();
					String[] content = line.split(": ");
					
					//content contains the word and definition
					//separated by : and a space
					wordTemp.add(content[0].trim());
					defTemp.add(content[1].trim());
				}
				
				//turn the two ArrayLists to array
				String[] words = wordTemp.toArray(new String[wordTemp.size() - 1]);
				String[] definitions = defTemp.toArray(new String[defTemp.size() - 1]);
				
				dictionary = new Dictionary(words, definitions);
			}
			catch (FileNotFoundException ex)
			{
				System.out.println(ex.getMessage());
			}
		}
		
		// choice is 2 -> word look up
		else if (choice == 2)
		{
			System.out.println("Please enter a word: ");
			userWord = scan.next();
			
			if (dictionary.hasWord(userWord))
			{
				String definition = dictionary.define(userWord);
				
				//if word does not have definition
				if(definition.equals(null))
				{
					System.out.println("Please enter a definition for \"" + userWord + "\": ");
					userDef = scan.nextLine();
					
					dictionary.updateDictionary(userWord, userDef);
				}
				//if word has a definition
				else 
				{
					System.out.println("Definition: " + definition);
				}
			}
		}
		// choice is 3 -> exit program
		else if (choice == 3)
		{
			System.out.println("------Thanks for viewing my dictionary!------");
		}
		
		// invalid choice
		else 
		{
			System.out.println("Please enter a valid number.");
		}
	}
}//end UserConsole