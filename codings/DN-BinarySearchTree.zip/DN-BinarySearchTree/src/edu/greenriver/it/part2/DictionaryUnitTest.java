package edu.greenriver.it.part2;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit testing for our dictionary class
 * Surprisingly this was fun to write
 * @author Duck Nguyen
 * @version 1.0
 * 05/16/17
 */
public class DictionaryUnitTest 
{
	private Dictionary tester;
	
	@Before
	//this method will run before all other method
	public void setup()
	{
		tester = new Dictionary();
	}
	
	private void addThem()
	{
		tester.updateDictionary("-A", "first letter in the alphabet");
		tester.updateDictionary("-B", "second letter in the alphabet");
		tester.updateDictionary("-C", "third letter in the alphabet");
		tester.updateDictionary("-D", "fourth letter in the alphabet");
	}
	
	@Test
	public void testDefaultConstructor()
	{
		//testing default constructor
		Dictionary temp = new Dictionary();
		Assert.assertEquals("Size should be 0", 0, temp.size());
	}
	
	@Test
	public void testParamConstructor()
	{
		//testing parameterized constructor
		String[] unsortedWords = {"d", "b","a", "z", "i"};
		String[] random = {"woopa", "foo", "salad", "Rockerfeller", "teehee"};
		
		//testing unsortedWords
		try
		{
			Dictionary temp = new Dictionary(unsortedWords, random);
			Assert.fail("IllegalStateException was not thrown when unsorted array is passed in");
		}
		catch (IllegalStateException ex)
		{
			//trying to go here
		}
		
		//testing different size
		String[] different = {"d", "b","a"};
		try
		{
			Dictionary temp = new Dictionary(different, random);
			Assert.fail("IllegalArgumentException was not thrown when uneven arrays are passed in");
		}
		catch (IllegalArgumentException ex)
		{
			//trying to go here
		}
		
		//legal case
		String[] sorted = {"a", "b", "c", "d", "e"};
		Dictionary temp2 = new Dictionary(sorted, random);
		Assert.assertEquals("Size should return 5", 5, temp2.size());
	}
	
	@Test
	public void testUpdate()
	{	
		//make sure I can add word/definition pairs to dictionary
		addThem();
		tester.updateDictionary("-Z", "last letter in the alphabet");
		//check if size has changed after adding words
		//check if dictionary contains a word/definition pair
		Assert.assertEquals("The size() of the dictionary should be 5 after adding 5 elements",
				5, tester.size());
		Assert.assertTrue("Should return true that our dictionary has the letter '-C'",tester.hasWord("-C"));
		
		//update a word with new definition
		Assert.assertEquals("The current definition of '-C'", "third letter in the alphabet", tester.define("-C"));
		tester.updateDictionary("-C", "A programming language that most people prefer over Java");
		
		//check definition should be updated
		Assert.assertEquals("The new definition of '-C'", 
				"A programming language that most people prefer over Java", tester.define("-C"));
		
		//check size should not change after update
		Assert.assertEquals("The size() of the dictionary should still be 5 after updating '-C'",
				5, tester.size());	
		
		//test that IllegalArgumentException() is thrown when a null key is passed in
		try
		{
			tester.updateDictionary(null, "indicating the amount of sleep a programmer gets on average");
			
			//should not reach here
			Assert.fail("IllegalArgumentException() was not thrown even though a null key is passed in");
		}
		catch (IllegalArgumentException c)
		{
			//trying to go here
		}
	}
	
	@Test
	public void testHasWord()
	{
		//verify that we can find a word in dictionary
		tester.updateDictionary("-A", "first letter in the alphabet");
		Assert.assertTrue("hasWord() should return true if '-A' is found in dictionary",tester.hasWord("-A"));
		
		//verify that we cannot find a certain word in dictionary
		Assert.assertFalse("hasWord() should return false if '-Z' is not found in dictionary",tester.hasWord("-Z"));
	}
	
	@Test
	public void testDefine()
	{
		//verify that we cannot find a definition if not in dictionary
		Assert.assertEquals("Define should return null when looking up word that's not in dictionary",
				null, tester.define("-A"));	
				
		//verify that we can find a word's definition in dictionary
		tester.updateDictionary("-A", "first letter in the alphabet");
		tester.updateDictionary("-B", "second letter in the alphabet");
		tester.updateDictionary("-C", "third letter in the alphabet");
		Assert.assertEquals("Should return the correct definition for '-A'",
				"first letter in the alphabet", tester.define("-A"));	
		
		//test that IllegalArgumentException() is thrown when a null key is passed in
		try
		{
			tester.define(null);
			//should not reach here
			Assert.fail("IllegalArgumentException() was not thrown even though a null key is passed in");
		}
		catch (IllegalArgumentException c)
		{
			//trying to go here
		}	
	}
	
	@Test
	public void testListWords()
	{
		tester.updateDictionary("-A", "first letter in the alphabet");
		tester.updateDictionary("-Z", "last letter in the alphabet");
		tester.updateDictionary("-S", "somewhere letter in the alphabet");
		tester.updateDictionary("-F", "fourth letter in the alphabet");
		String[] correct = {"-A", "-F", "-S", "-Z"};
		Assert.assertArrayEquals("Should return ordered (inorder) list of words", correct, tester.words().toArray());
	}
	
	@Test
	public void testListDefinition()
	{
		tester.updateDictionary("-A", "first letter in the alphabet");
		tester.updateDictionary("-Z", "last letter in the alphabet");
		tester.updateDictionary("-S", "somewhere letter in the alphabet");
		tester.updateDictionary("-F", "fourth letter in the alphabet");
		String[] correct = {"first letter in the alphabet", "fourth letter in the alphabet", "somewhere letter in the alphabet", 
				"last letter in the alphabet"};
		Assert.assertArrayEquals("Should return unordered list of definitions", correct, tester.definitions().toArray());
	}
	
	@Test
	public void testSize()
	{
		//verify size() is zero when the dictionary is empty
		Assert.assertEquals("Size should be 0 when dictionary is empty", 0, tester.size());
		
		//verify size() increases as word/definition pairs are added
		addThem();
		Assert.assertEquals("Size should be 4 after 4 pairs are added", 4, tester.size());
		
		//verify size() stays the same when words are updated
		tester.updateDictionary("-A", "Highest level in the grade scale");
		tester.updateDictionary("-B", "Second highest level in the grade scale");
		Assert.assertEquals("Size should still be 4 after pairs are updated", 4, tester.size());
		
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when dictionary is empty", 0, tester.size());
	}
	
	@Test
	public void testEmpty()
	{
		//isEmpty() should return true because dictionary is empty
		Assert.assertTrue("isEmpty() should return true because dictionary is currently empty",tester.isEmpty());
		
		//add two pairs to check
		tester.updateDictionary("-A", "first letter in the alphabet");
		tester.updateDictionary("-B", "second letter in the alphabet");
		
		//isEmpty() should return false because dictionary is not empty
		Assert.assertFalse("isEmpty() should return false because dictionary contains 2 pairs now",tester.isEmpty());
	}
	
	@Test
	public void testClear()
	{
		//add a single pair to dictionary
		tester.updateDictionary("-A", "first letter in the alphabet");
		
		//check current size of dictionary
		Assert.assertEquals("The size() of the dictionary should be 1 after adding 1 elements", 1, tester.size());
				
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when dictionary is empty", 0, tester.size());	
				
		//add couple pairs to dictionary
		addThem();
		
		//check current size of dictionary
		Assert.assertEquals("The size() of the dictionary should be 4 after adding 4 elements", 4, tester.size());
		
		//verify size() is zero when clear() is called
		tester.clear();
		Assert.assertEquals("Size should be 0 when dictionary is empty", 0, tester.size());		
	}
}//end DictionaryUnitTest