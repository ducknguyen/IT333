package edu.greenriver.it.trees;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class BinarySearchTree<T extends Comparable<T>> implements Iterable<T> {
	//fields
	private Node root;
	private int size;
	
	public BinarySearchTree()
	{
		//do nothing
	}
	
	//basic methods
	public void add(T element)
	{
		//empty tree?
		if(root == null)
		{
			root = new Node(element);
			size++; //dont forget to increment size
		}
		else
		{
			//we need to recursively find the position of our new element
			root = add(element, root);
		}
	}
	
	private Node add(T element, Node current)
	{
		//if we have current node, then we found an open spot
		if(current == null)
		{
			size++;
			return new Node(element);
		}
		
		//are we looking to the left and right
		int compare = current.data.compareTo(element);
		
		if(compare < 0) //current smaller
		{
			current.right = add(element, current.right);
			return current;
		}
		else if (compare > 0) //current larger
		{
			current.left = add(element, current.left);
			return current;
		}
		return current; //don't add a new element 
	}
	
	public boolean contains(T element)
	{
		return contains(element, root);
	}
	
	private boolean contains(T element, Node current)
	{
		//base case?
		if(current == null)
		{
			return false;
		}
		
		int compare = current.data.compareTo(element);
		
		if(compare < 0) //current smaller
		{
			return contains(element, current.right);
		}
		else if (compare > 0) //current larger
		{
			return contains(element, current.left);
		}
		else //current equal
		{
			return true;
		}
	}
	//return true if the element is found and removed, otherwise returns false
	public void remove(T element)
	{
		root = remove(element, root);
	}
	
	private Node remove(T element, Node current)
	{
		//base case?
		if(current == null)
		{
			return null; //not found
		}
		
		int compare = current.data.compareTo(element);
		
		if (compare < 0)
		{
			current.right = remove(element, current.right);
		}
		else if (compare > 0)
		{
			current.left = remove(element, current.left);
		}
		else //current equal 
		{
			//two children
			if (current.left != null && current.right != null)
			{
				//replace the data at our current node
				Node maxLeft = findMax(current.left);
				current.data = maxLeft.data;
				
				//recursively remove the largest element in the left subtree
				current.left = remove(maxLeft.data, current.left);
				
				//not necessary
				//size--;
			}
			else if (current.left != null) //one child
			{
				current = current.left;
				size--;
			}
			else if (current.right != null) //one child
			{
				current = current.right;
				size--;
			}
			else //no children
			{
				current = null;
				size--;
			}
		}
		return current;
	}
	
	private Node findMax(Node current)
	{
		if (current.right != null)
		{
			return findMax(current.right);
		}
		return current;
	}
	public int size()
	{
		return size;
	}
	
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	public void clear()
	{
		root = null;
		size = 0;
	}
	
	//inOrder traversing l-n-r
	public void inOrder()
	{
		inOrder(root);
	}
	
	public void inOrder(Node current)
	{
		if (current != null)
		{
			inOrder(current.left); //left
			System.out.println(current); //node
			inOrder(current.right); //right
		}
	}
	
	//postOrder traversing l-r-n
	public void postOrder()
	{
		postOrder(root);
	}
	
	public void postOrder(Node current)
	{
		if (current != null)
		{
			inOrder(current.left); //left
			inOrder(current.right); //right
			System.out.println(current); //node		
		}
	}
	
	//postOrder traversing n-l-r
	public void preOrder()
	{
		preOrder(root);
	}
	
	public void preOrder(Node current)
	{
		if (current != null)
		{
			System.out.println(current); //node
			inOrder(current.left); //left
			inOrder(current.right); //right
		}
	}
	
	public List<T> toList()
	{
		List<T> results = new ArrayList<>();
		toList(root, results);
		
		return results;
	}
	
	private void toList(Node current, List<T> results)
	{
		if (current != null)
		{
			inOrder(current.left); //left
			System.out.println(current); //node
			inOrder(current.right); //right
		}		
	}
	@Override
	public Iterator<T> iterator() {
		return new BSTIterator(root);
	}
	
	@SuppressWarnings("unchecked")
	private class NaiveIterator implements Iterator<T>
	{
		private Object[] data;
		private int position;
		
		public NaiveIterator(BinarySearchTree<T> owner)
		{
			data = owner.toList().toArray();
		}
		
		@Override
		public boolean hasNext()
		{
			return position < data.length;
		}
		
		@Override
		public T next()
		{
			return (T)data[position++];
		}
	}
	
	private class BSTIterator implements Iterator<T>
	{
		private Stack<Node> nodeStack = new Stack<>();
		
		public BSTIterator(Node current)
		{
			//move to the first node
			while (current != null)
			{
				nodeStack.push(current);
				current = current.left;
			}
		}
		
		@Override
		public boolean hasNext()
		{
			return !nodeStack.isEmpty();
		}
		
		@Override
		public T next()
		{
			//step #1: retrieve the next element to report
			Node next = nodeStack.pop();
			
			//step #2: if there's a right sub-tree, find the smallest element
			//adding nodes to the stack as we go
			if(next.right != null)
			{
				//add the right child
				nodeStack.push(next.right);
				
				//dive to the left of our right child
				Node current = next.right;
				while (current.left != null)
				{
					nodeStack.push(current.left);
					current = current.left;
				}
			}
			return next.data;
		}
	}
	
	//binary search tree node
	private class Node
	{
		private T data;
		private Node left;
		private Node right;
		
		public Node(T data)
		{
			this.data = data;
		}
		
		public String toString()
		{
			//using the ternary operator
			String dataString = (data == null) ? "null":data.toString();
			String leftChild = (left == null) ? "null":left.data.toString();
			String rightChild = (right == null) ? "null":right.data.toString();
			
			return leftChild + "<-- " + dataString + " -->" + rightChild;
		}
	}
}
