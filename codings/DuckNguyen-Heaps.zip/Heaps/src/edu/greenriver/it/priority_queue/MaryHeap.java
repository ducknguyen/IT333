package edu.greenriver.it.priority_queue;

import java.util.Arrays;

/**
 * This class acts as a priority queue using an 5-ary min-heap.
 * 
 * 05/27/17
 * @author Duck Nguyen
 * @version 1.0
 */
public class MaryHeap<T extends Comparable<T>>
{
	//private constants for initial size, resize factor, and number of children
	private static final int INIT_SIZE = 10;
	private static final int RESIZE_FACTOR = 2;
	private static final int M_CHILDREN = 5;
	
	//internal array "data" to store 5-ary children
	private T[] data;
	private int size;
	
	/**
	 * Default constructor for Mary
	 * 
	 */
	@SuppressWarnings("unchecked")
	public MaryHeap()
	{
		data = (T[]) new Comparable[INIT_SIZE];
	}
	
	/**
	 * Places an element into the heap and reorders the elements in the heap
	 * 
	 * @param element - element to insert into our heap
	 */
	public void insert(T element)
	{
		//data is empty
		if (size == 0) 
		{
			data[size++] = element;
			
		}
		else 
		{
			//add the new element
			//increment size after
			data[size++] = element;
			swim(size-1);
		}
		//resize data if necessary
		if (size >= data.length - 1)
		{
			resize();
		}
	}
	
	/**
	 * Removes the minimum element from the heap and reorders the elements in the heap
	 * 
	 * @return the min value (root)
	 */
	public T delMin()
	{
		//removes AND returns the minimum element in the heap
		if (isEmpty())
		{
			return null;
		}
		
		//save our result
		T result = data[0];
		
		//move the top index to the root of the tree
		swap(0, size-1);
		size--;
		sink(0);
		
		//System.out.println("Data content after delMin(): " + Arrays.toString(data));
		return result;
	}
	
	/**
	 * Bottom-up re-heapify 
	 * when a node's key becomes larger than that node's parents key
	 * 
	 * @param index of element out of order
	 */
	private void swim(int index)
	{
		//stop when we reach the root (index 0)
		while (index > 0)
		{
			//System.out.println("Data content: " + Arrays.toString(data));
			//System.out.println("index: " + index);
			int parentIndex = (index-1) / M_CHILDREN;
			
			//System.out.println("Child: " + data[index] + " Parent: " + data[parentIndex]);
			
			if (data[index].compareTo(data[parentIndex]) < 0)
			{
				swap(index, parentIndex);
			}
			
			index = parentIndex;
		}
	}
	
	/**
	 * Top-down heapify 
	 * when a node's key becomes smaller than that node's children key
	 * 
	 * @param index of element out of order
	 */
	private void sink(int index)
	{
		while (index <= size / RESIZE_FACTOR)
		{
			//array holding a parent's children
			int[] childs = new int[M_CHILDREN];
			
			for (int i = 0; i < childs.length; i++){
				childs[i] = M_CHILDREN * index + i + 1;
			}
			
			//start from 1st child
			int indexToCheck = childs[0];
			
			//find smallest child of all children
			for (int i = 1; i < childs.length; i++) {
				if (childs[i] < data.length && data[childs[i]] != null && 
						data[childs[i]].compareTo(data[indexToCheck]) < 0)
				{
					indexToCheck = childs[i] ;
				}
			}
			
			//compare the parent with the smallest child
			if (data[indexToCheck].compareTo(data[index]) < 0)
			{
				swap(indexToCheck, index);
				index = indexToCheck;
			}
			else
			{
				break;
			}
		}
	}
	
	/**
	 * Dynamically resize internal array
	 * 
	 */
	@SuppressWarnings("unchecked")
	private void resize()
	{
		T[] newData = (T[])new Comparable[data.length * RESIZE_FACTOR];
		
		//copy across all elements
		for (int i = 0; i < data.length; i++)
		{
			newData[i] = data[i];
		}
		
		data = newData;
	}
	
	/**
	 * Helper function to swap elements position within array
	 * 
	 */
	private void swap(int first, int second)
	{
		T temp = data[first];
		data[first] = data[second];
		data[second] = temp;
	}
	
	/**
	 * Returns the element at index zero in array
	 * 
	 * @return null if array is empty
	 * @return element at index zero
	 */
	public T peek()
	{
		if(data.length == 0)
		{
			return null;
		}
		return data[0];
	}
	
	/**
	 * Returns current size of internal array
	 * 
	 * @return current size of internal array
	 */
	public int size()
	{
		return size;
	}
	
	/**
	 * Check if the heap is empty
	 * 
	 * @return true if empty, false otherwise
	 */
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	/**
	 * Removes all elements from the heap
	 * 
	 */
	public void clear()
	{
		this.size = 0;
	}
	
	/**
	 * Check if Mary contains an element
	 * 
	 * @return true if element is found in heap, false otherwise
	 */
	public boolean contains(T element)
	{
		return Arrays.asList(data).contains(element);
	}	
}// end MaryHeap