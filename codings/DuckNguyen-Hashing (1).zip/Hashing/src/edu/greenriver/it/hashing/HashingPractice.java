package edu.greenriver.it.hashing;

import edu.greenriver.it.hashing.MyHashTable;

public class HashingPractice 
{
	public static void main(String[] args) 
	{		
		MyHashTable<String> wordsSet = new MyHashTable<String>();
		// add a few elements
		wordsSet.add("red");
		wordsSet.add("black");
		wordsSet.add("blue");
		wordsSet.add("green");
		wordsSet.add("white");
		wordsSet.add("pink");
		System.out.println("Before rehash(): " + wordsSet.toString());
		
		wordsSet.add("purple");
		
		//view the contents of the internal array
		System.out.println("After rehash(): " + wordsSet.toString());
		
		//practice with remove and contains
		System.out.println("remove (red): " + wordsSet.remove("red"));
		System.out.println("remove (brown): " + wordsSet.remove("brown"));
		System.out.println("contains (white): " + wordsSet.contains("white"));
		System.out.println("contains (cyan): " + wordsSet.contains("cyan"));
		
		System.out.println("size(): " + wordsSet.size());
		System.out.println("isEmpty(): " + wordsSet.isEmpty());
		
		// use iterator here
		for (String word : wordsSet)
		{
			System.out.println(word);
		}
	}
}//end HashingPractice